/*
# Create expenses table (single-tenant, no auth)

1. New Tables
- `expenses`
  - `id` (uuid, primary key, auto-generated)
  - `name` (text, not null) — the expense description
  - `amount` (numeric, not null) — the monetary value
  - `category` (text, not null) — one of: Food, Transport, Entertainment, Shopping, Bills, Other
  - `created_at` (timestamptz, defaults to now)
2. Security
- Enable RLS on `expenses`.
- Allow anon + authenticated full CRUD because the data is intentionally shared/public (no sign-in app).
3. Notes
- Uses `USING (true)` / `WITH CHECK (true)` because this is a single-tenant app with no authentication.
- Index on `created_at` for efficient ordering by recency.
*/

CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  amount numeric(12, 2) NOT NULL CHECK (amount > 0),
  category text NOT NULL CHECK (category IN ('Food', 'Transport', 'Entertainment', 'Shopping', 'Bills', 'Other')),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_expenses_created_at ON expenses (created_at DESC);

ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_expenses" ON expenses;
CREATE POLICY "anon_select_expenses" ON expenses FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_expenses" ON expenses;
CREATE POLICY "anon_insert_expenses" ON expenses FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_expenses" ON expenses;
CREATE POLICY "anon_update_expenses" ON expenses FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_expenses" ON expenses;
CREATE POLICY "anon_delete_expenses" ON expenses FOR DELETE
  TO anon, authenticated USING (true);
